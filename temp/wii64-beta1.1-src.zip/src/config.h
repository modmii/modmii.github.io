#ifndef CONFIG_H
#define CONFIG_H

#undef WITH_HOME
#undef VCR_SUPPORT
#define GTK2_SUPPORT 1

#endif /* CONFIG_H */
