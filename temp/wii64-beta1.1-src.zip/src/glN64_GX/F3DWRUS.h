/**
 * glN64_GX - F3DWRUS.h
 * Copyright (C) 2003 Orkin
 *
 * glN64 homepage: http://gln64.emulation64.com
 * Wii64 homepage: http://www.emulatemii.com
 *
**/

#ifndef F3DWRUS_H
#define F3DWRUS_H

#define F3DWRUS_TRI2		0xB1
void F3DWRUS_Init();

#endif

