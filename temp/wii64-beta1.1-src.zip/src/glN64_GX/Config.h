/**
 * glN64_GX - Config.h
 * Copyright (C) 2003 Orkin
 *
 * glN64 homepage: http://gln64.emulation64.com
 * Wii64 homepage: http://www.emulatemii.com
 *
**/

#ifndef CONFIG_H
#define CONFIG_H
void Config_LoadConfig();
void Config_DoConfig();
#endif

