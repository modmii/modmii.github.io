/**
 * glN64_GX - F3DPD.h
 * Copyright (C) 2003 Orkin
 *
 * glN64 homepage: http://gln64.emulation64.com
 * Wii64 homepage: http://www.emulatemii.com
 *
**/

#ifndef F3DPD_H
#define F3DPD_H

#define F3DPD_VTXCOLORBASE		0x07

void F3DPD_Init();
#endif

