/**
 * glN64_GX - RDP.h
 * Copyright (C) 2003 Orkin
 *
 * glN64 homepage: http://gln64.emulation64.com
 * Wii64 homepage: http://www.emulatemii.com
 *
**/

#ifndef RDP_H
#define RDP_H

void RDP_Init();

#endif

