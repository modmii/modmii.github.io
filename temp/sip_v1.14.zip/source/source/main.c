#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gccore.h>
#include <malloc.h>
#include <network.h>
#include <ogc/machine/processor.h>
#include <ogc/machine/asm.h>
#include "IOSPatcher.h"
#include "wad.h"
#include "tools.h"
#include "title.h"
#include "RuntimeIOSPatch.h"

#define IOS15version 1031
#define IOS36version 3351

#define HW_MEMMIRR 0x0d800060
#define HW_AHBPROT 0x0d800064 // defaults to 0xFFFFFFFF on boot


// Prevent IOS36 loading at startup
s32 __IOS_LoadStartupIOS()
{
	return 0;
}

s32 __u8Cmp(const void *a, const void *b)
{
	return *(u8 *)a-*(u8 *)b;
}

u8 *get_ioslist(u32 *cnt)
{
	u64 *buf = 0;
	s32 i, res;
	u32 tcnt = 0, icnt;
	u8 *ioses = NULL;
	
	//Get stored IOS versions.
	res = ES_GetNumTitles(&tcnt);
	if(res < 0)
	{
		printf("ES_GetNumTitles: Error! (result = %d)\n", res);
		return 0;
	}
	buf = memalign(32, sizeof(u64) * tcnt);
	res = ES_GetTitles(buf, tcnt);
	if(res < 0)
	{
		printf("ES_GetTitles: Error! (result = %d)\n", res);
		if (buf) free(buf);
		return 0;
	}

	icnt = 0;
	for(i = 0; i < tcnt; i++)
	{
		if(*((u32 *)(&(buf[i]))) == 1 && (u32)buf[i] > 2 && (u32)buf[i] < 0x100)
		{
			icnt++;
			ioses = (u8 *)realloc(ioses, sizeof(u8) * icnt);
			ioses[icnt - 1] = (u8)buf[i];
		}
	}

	ioses = (u8 *)malloc(sizeof(u8) * icnt);
	icnt = 0;
	
	for(i = 0; i < tcnt; i++)
	{
		if(*((u32 *)(&(buf[i]))) == 1 && (u32)buf[i] > 2 && (u32)buf[i] < 0x100)
		{
			icnt++;
			ioses[icnt - 1] = (u8)buf[i];
		}
	}
	free(buf);
	qsort(ioses, icnt, 1, __u8Cmp);

	*cnt = icnt;
	return ioses;
}


int ios_selectionmenu(int default_ios)
{
	u32 pressed;
	u32 pressedGC;
	int selection = 0;
	u32 ioscount=4;
	static int list[4] = {36, 60, 70, 80};
	int i;
	for (i=0;i<ioscount;i++)
	{
		// Default to default_ios if found, else the loaded IOS
		if (list[i] == default_ios)
		{
			selection = i;
			break;
		}
		if (list[i] == IOS_GetVersion())
		{
			selection = i;
		}
	}	
	
	while (true)
	{
		printf("\x1B[%d;%dH",2,0);	// move console cursor to y/x
		
		printf("Select which IOS to patch:       \b\b\b\b\b\b");

		set_highlight(true);
		printf("IOS%u\n", list[selection]);
		set_highlight(false);
		
		printf("Press B to exit.\n");
		waitforbuttonpress(&pressed, &pressedGC);
		
		if (pressed == WPAD_BUTTON_LEFT || pressedGC == PAD_BUTTON_LEFT)
		{	
			if (selection > 0)
			{
				selection--;
			} else
			{
				selection = ioscount - 1;
			}
		}
		if (pressed == WPAD_BUTTON_RIGHT || pressedGC == PAD_BUTTON_RIGHT)
		{
			if (selection < ioscount -1	)
			{
				selection++;
			} else
			{
				selection = 0;
			}
		}
		if (pressed == WPAD_BUTTON_A || pressedGC == PAD_BUTTON_A) break;
		if (pressed == WPAD_BUTTON_B || pressedGC == PAD_BUTTON_B)
		{
			return 256;
		}
		
	}
	return list[selection];
}


void show_boot2_info()
{
	int ret;
	printf("\x1b[2J");
	printheadline();
	printf("\n");

	printf("Retrieving boot2 version...\n");
	u32 boot2version = 0;
	ret = ES_GetBoot2Version(&boot2version);
	if (ret < 0)
	{
		printf("Could not get boot2 version. It's possible your Wii is\n");
		printf("a boot2v4+ Wii, maybe not.\n");
	} else
	{
		printf("Your boot2 version is: %u\n", boot2version);
		if (boot2version < 4)
		{
			printf("This means you should not have problems.\n");
		}
	}	
	
	printf("\n");
	printf("Boot2v4 is an indicator for the 'new' Wii hardware revision that prevents\n");
	printf("the execution of some old IOS. These Wiis are often called LU64+ Wiis or\n");
	printf("'unsoftmoddable' Wiis. You MUST NOT downgrade one of these Wiis and be\n");
	printf("EXTRA careful when messing with ANYTHING on them.\n");
	printf("The downgraded IOS15 you get with the Trucha Bug Restorer should work\n");
	printf("on these Wiis and not harm Wiis in general.\n");
	printf("\n");
	printf("If you updated your Wii via wifi to 4.2 or higher, your boot2 got\n");
	printf("updated by this and you can't use it as indicator for this.\n");
	printf("\n");
	printf("Press any button to return to the menu\n");
	waitforbuttonpress(NULL, NULL);
}


int iosinstallmenu(u32 ios)
{
	u32 pressed;
	u32 pressedGC;
	u32 maxoptions = 0;
	int selection = 0;
	int destselect = 0;
	int ret;
	int i;
	u32 revision;
	u32 outrevision;
	if (ios==36) { 
	revision=3351;
	outrevision=3608;
	}
	if (ios==60) {
	revision=6174;
	outrevision=6174;
	}
	if (ios==70) {
	revision=6687;
	outrevision=6687;
	}
	if (ios==80) {
	revision=6944;
	outrevision=6944;
	}
	bool options[5] = { true, false, false, false, false};
	if (ios==36) {
		options[1] = true;
		options[2] = true;
		options[3] = true;
		options[4] = true;
	} 

	char *optionsstring[5] = {	"Patch hash check (trucha): ",
								"Patch ES_Identify:         ",
								"Patch nand permissions:    ",
								"Patch version check:       ",
								"Patch ES_set_AHBPROT:      "};
								
	u32 destination[6] = { ios, 236, 249, 11, 20, 30 };
	
	while (true)
	{
		printf("\x1b[2J");
		printheadline();
		printf("\n");
		
		set_highlight(selection == 0);
		if (options[0] || options[1] || options[2] || options[3] || options[4] || ios != destination[destselect])
		{
			printf("Install patched IOS%u\n", ios);
		} else
		{
			printf("Install IOS%u\n", ios);
		}
		set_highlight(false);

		printf("Install IOS to slot:       ");
		set_highlight(selection == 1);
		printf("%u\n", destination[destselect]);
		set_highlight(false);
		
		if (ios == 36)
		{
			maxoptions = 5;
		} else
		{
			maxoptions = 1;
		}
		
		for (i=0;i < maxoptions;i++)
		{
			printf(optionsstring[i]);
			set_highlight(selection == i+2);
			printf("%s\n", options[i] ? "yes" : "no");
			set_highlight(false);
		}
		printf("\n");
		printf("Press B to return to the main menu.\n");
		
		waitforbuttonpress(&pressed, &pressedGC);
		
		if (pressed == WPAD_BUTTON_LEFT || pressedGC == PAD_BUTTON_LEFT)
		{	
			if (selection == 1)
			{
				if (destselect > 0)
				{
					destselect--;
				} else
				{
					destselect = 5;
				}
			}
			if (selection > 1)
			{
				options[selection-2] = !options[selection-2];
			}
		}

		if (pressed == WPAD_BUTTON_RIGHT || pressedGC == PAD_BUTTON_RIGHT)
		{	
			if (selection == 1)
			{
				if (destselect < 5)
				{
					destselect++;
				} else
				{
					destselect = 0;
				}
			}
			if (selection > 1)
			{
				options[selection-2] = !options[selection-2];
			}
		}
		
		if (pressed == WPAD_BUTTON_UP || pressedGC == PAD_BUTTON_UP)
		{
			if (selection > 0)
			{
				selection--;
			} else
			{
				selection = maxoptions+1;
			}
		}

		if (pressed == WPAD_BUTTON_DOWN || pressedGC == PAD_BUTTON_DOWN)
		{
			if (selection < maxoptions+1)
			{
				selection++;
			} else
			{
				selection = 0;
			}
		}

		if ((pressed == WPAD_BUTTON_A || pressedGC == PAD_BUTTON_A) && selection == 0)
		{
			if (destination[destselect] == 36 || destination[destselect] == 60 || destination[destselect] == 70 || destination[destselect] == 80)
			{
				ret = Install_patched_IOS(ios, revision, options[0], options[1], options[2], options[3], options[4], destination[destselect], outrevision);
			} else
			{
				ret = Install_patched_IOS(ios, revision, options[0], options[1], options[2], options[3], options[4], destination[destselect], 65535);
			}
			if (ret < 0)
			{
				printf("IOS%u installation failed.\n", ios);
				printf("Press any button to exit...\n");
				waitforbuttonpress(NULL, NULL);
	
				Reboot();
				return -1;
			} else {
			printf("Success!");
			sleep(5);
			}
			return 0;
		}
		
		if (pressed == WPAD_BUTTON_B || pressedGC == PAD_BUTTON_B)
		{
			printf("Installation cancelled\n");
			return 0;
		}		
	}	
	printf("\x1b[2J");
	fflush(stdout);
}


int main(int argc, char* argv[])
{
	
	int ret = 0;
	ret = IOSPATCH_Apply();
	Init_Console();
	printf("\x1b[%u;%um", 37, false);

	PAD_Init();
	WPAD_Init();
	WPAD_SetDataFormat(WPAD_CHAN_0, WPAD_FMT_BTNS_ACC_IR);
	
	printheadline();

	if (ret > 0) {
		while (true) {
			sleep(1);
			ret = ios_selectionmenu(36);
			if (ret==256) break;
			if (ret != 0)
			{
				iosinstallmenu(ret);
				printf("\x1b[2J");
				fflush(stdout);
				printheadline();
			} 
		}
	} else {
		printf("HW_AHBPROT could not be used, please load this App with the\n");
		printf("HBC 1.0.7 or higher and set \"<no_ios_reload/>\" in the meta.xml\n");
		printf("Press any button to exit...\n");
		waitforbuttonpress(NULL, NULL);
	}

	printf("\n");
	

	//mainmenu();
	
	Close_SD();
	Close_USB();
	
	//printf("Press any button to exit...\n");
	//waitforbuttonpress(NULL, NULL);
	
	printf("Goodbye!");
	Reboot();
	

	return 0;
}
