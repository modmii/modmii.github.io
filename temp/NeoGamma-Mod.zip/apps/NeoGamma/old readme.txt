This program is a modification of GeckoOS, and is unsupported and not condoned by the original authors of it. The backup loader modification is solely the work of WiiGator.

The original GeckoOS was made possible by Nuke, Kenobi, Link, Y.S. (DIY Hacker), XT5, bushing, dhewg, Foxx, SMK, and all USB Gecko forum members, so thanks to them for their hard work.

WiiGator

