Copy your GameCube games to the /games/ directory for use with Nintendont.

Subdirectories are optional for 1-disc games in ISO/GCM and CISO format.

For 2-disc games, you should create a subdirectory /games/MYGAME/ (where MYGAME can be anything), then name disc 1 as "game.iso" and disc 2 as "disc2.iso".


For extracted FST, the FST must be located in a subdirectory, e.g. /games/FSTgame/sys/boot.bin