MaterialMii by Vilagamer999 featuring:
- Cleaner icons
- Intuitive design
- Larger text
- Nicer colours
- Custom SFX
- Dark mode!