Thanks to Sir Gustav#6611 for making the theme!
Thanks to thepikachugamer#0976 for trimming the sounds!

Success Sound:
https://www.youtube.com/watch?v=wEr09Vi_bw0
Fail Sound:
https://www.youtube.com/watch?v=CD9S_cY_a1I
Awesome YouTube Channel:
https://www.youtube.com/channel/UCj9huwXZNV4rFiIkQV_7yBw
???:
https://www.youtube.com/watch?v=dQw4w9WgXcQ