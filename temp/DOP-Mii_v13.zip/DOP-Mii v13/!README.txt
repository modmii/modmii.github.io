Thank you for downloading DOP-Mii!

Upgrading System Menu to 4.3 is currently disabled as the System Menu will remove the Homebrew Channel.

If any issues are found please open a ticket @ https://code.google.com/p/dop-mii/issues/list

Changelog:

v13:
-Made all of the components in 4.3 available to install (with the exception of the System Menu)
-Changed the fakesign IOS installtion routine to support more users (including some on 4.3)
-Bugfix: The application should now be able to be used by users on 4.3