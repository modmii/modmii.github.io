// Public domain, blah blah blah, use however you like

#include <stdio.h>
#include <string.h>
#include <conio.h>

int main() {
	FILE *NAND = NULL, *keyFile = NULL;
	NAND = fopen("keys.bin", "rb");
	int usingNandBin = 0;

	if (NAND == NULL) {
		NAND = fopen("nand.bin", "rb");

		if (NAND == NULL) {
			puts("neither nand.bin nor keys.bin found, aborting");
			goto end;
		} else {
			puts("found nand.bin, using it");
			usingNandBin = 1;
		}
	} else {
		puts("found keys.bin, using it");
	}

	if (fseek(NAND, -0x0400, SEEK_END) == -1L) {
		puts("file doesn't look like it contains a key dump, aborting");
		goto end;
	}

	char sig[12];
	fread(sig, 12, 1, NAND);

	if (memcmp(sig, "BackupMii v1", 12) != 0) {
		if (usingNandBin)
			puts("file doesn't look like it contains a key dump, it might be\n"
			     "because it was made using BootMii beta 3, in which case you\n"
			     "will need keys.bin as well, aborting");
		else
			puts("file doesn't look like it contains a key dump, aborting");

		goto end;
	}

	fseek(NAND, -0x02A8, SEEK_END);
	unsigned char key[16];
	fread(key, 16, 1, NAND);
	fclose(NAND);
	NAND = NULL;
	puts("NAND AES key found!\n");
	int i;

	for (i = 0; i < 16; i++)
		printf(" %02X", key[i]);

	printf("\n\nwriting to nand-key.bin... ");
	keyFile = fopen("nand-key.bin", "w+b");

	if (keyFile == NULL) {
		puts("couldn't save key to file, try making it manually with a hex editor");
		goto end;
	}

	fwrite(key, 16, 1, keyFile);
	fclose(keyFile);
	keyFile = NULL;
	puts("done");

end:
	if (NAND != NULL)
		fclose(NAND);

	if (keyFile != NULL)
		fclose(keyFile);

	printf("\n\npress any key to exit");
	while (!_kbhit());
	printf("\n");
	return 0;
}
