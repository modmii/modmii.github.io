MyMenuifyMOD

by Scooby74029


change log:
---------------------------------------------------------------------------
v1.6
-compiled with newest devkitpro

v1.5
-compiled with newest devkitpro
-new wiimotes should work

v1.4
-added ability to detect custom system menu versions

v1.3a
-added translation for Spanish

v1.3
-added translation for Japanese
-fixed all compiling errors
-started work on smb share

v1.2a

-added classic controller support(untested since i dont have a classic controller)
-some bug fixes

v1.2

-added one button press install of original system menu themeing file
-reworked the brick protection

**-known bug when trying to install a region different than the currently installed region -- app will code dump-- i need help solving this one

v1.1

-fixed bug when loadup ios is not installed
no asks

v 1.0
-SD changed theme folder to(folder "modthemes" on root of sd card)
-added Usb support (folder "modthemes" on root of usb device)
-checks for correct region and version(if the installed sysmenu theme  is equal to the sysmenu going to be installed it installs else it tells 	what was wrong and goes back to HBC)
-Uneek will install themes from SD(sneek might if it is compiled with the sd card on)

TODO:

-add theme .mym download
-add theme building(.mym to .csm)
-add ability to preveiw theme(before download)
-add ability to have U/Sneek for the "modthemes" folder(read and write)




------------------------------------------------------
All .csm or .app file must go in this folder structure:
-sd:/modthemes/*.csm or *.app
-USB:/modthemes/*.csm or *.app



--------------------------------------------------------

I would like to thank Icefire for the original MyMenuify and all the devs that i have taken code from or used as an example
