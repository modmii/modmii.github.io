﻿-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
           libWiiSharp
            by Leathl
   libwiisharp.googlecode.com
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-



Info:
-=-=-

libWiiSharp is a Wii related .NET (2.0+) library.
It can be used with any .NET language to easily develop Wii related applications.

All public functions are documented and most should be pretty self-explanatory.
There are also some example applications that use libWiiSharp included.

If you want to contribute, mail me at leathl[-at-]gmail[-dot-]com.



Thanks:
-=-=-=-

	- Xuzz, SquidMan, megazig, Matt_P, Omega and The Lemon Man for Wii.py
	- megazig for his bns conversion code (bns.py)
	- SquidMan for Zetsubou
	- Arikado and Lunatik for Dop-Mii
	- Andre Perrot for gbalzss



License:
-=-=-=-=-

libWiiSharp is released under the terms of the GNU General Public License v3.
See "License_libWiiSharp.txt" for more information.



Changelog:
-=-=-=-=-=-

See "Changelog_libWiiSharp.txt"