*** Configurator for Configurable USB Loader ***

The zip file for Configurator contains the following files:
- CfgLoaderConfigurator.exe    (The application itself)
- ConfiguratorHelp.chm         (Help documentation)
- Ionic.Zip.Reduced.dll        (DotNetZip unzip library)
- Readme.txt                   (This file)

To use this application, extract CfgLoaderConfigurator.exe and 
Ionic.Zip.Reduced.dll to any directory on your computer and 
double-click CfgLoaderConfigurator.exe.  Note: You only need 
to copy the .dll if you wish to use the Configurator's online 
self-update feature.

Things will be even easier if you place your files into the base 
directory of Configurable USB Loader (typically sd:/usb-loader).  
By doing this, the loader will detect the config.txt and other 
needed files as it starts up.

If you have translation files (a group of files ending in .cdb), 
add those to the same directory as CfgLoaderConfigurator.exe and 
they will also be utilised during startup.

Further information about the Configurator can be found at:
http://gbatemp.net/index.php?showtopic=174304
http://gwht.wikidot.com/configurable-options

Translations of the Configurator can be found at:
http://gbatemp.net/index.php?showtopic=205397

Further information about Configurable USB Loader can be found at:
http://gbatemp.net/index.php?showtopic=147638
http://docs.google.com/View?id=dhjktg6j_1gphhtrgn
http://gwht.wikidot.com/usb-loader
http://gwht.wikidot.com/configurable-options

Instructions for installing Homebrew and Configurable USB Loader 
on the Wii for non-pirates can be found at:
http://gwht.wikidot.com

The current splash image was designed by pedimaisum of GBATemp.
Assets for the splash were created with Artua Design Studio.

Enjoy!
Dr. Clipper