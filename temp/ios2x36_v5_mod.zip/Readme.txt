Here is the source just in case anyone wants it. I'm not, nor do I claim to be a programmer so it is ugly. I'm aware it isn't efficient at all, but it does what it needs to :)

burritoboy9984