void DrawBackground(GXRModeObj *vmode);

