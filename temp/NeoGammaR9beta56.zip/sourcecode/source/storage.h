#include <gccore.h>

char storagename[4];	

s32 prepare_storage_access();
s32 resume_disc_loading();
void storage_shutdown();

