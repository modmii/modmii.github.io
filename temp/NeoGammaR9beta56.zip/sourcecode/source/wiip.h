#include <gccore.h>

void wipreset();
void wipregisteroffset(u32 dst, u32 len);
bool wipparsebuffer(u8 *buffer, u32 length);


