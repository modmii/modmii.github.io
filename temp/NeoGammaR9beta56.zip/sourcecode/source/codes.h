#include <gccore.h>

#define gecko_channel 1

void do_codes(bool storageavailable);
void load_handler();
void app_pokevalues();

s32 load_codes(char *filename, u32 maxsize, u8 *buffer);


