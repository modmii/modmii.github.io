#ifndef _CODECMP_H_
#define _CODECMP_H_

#include "types.h"

int codecmp(void *checkedCode, const u32 *condition, u32 size);

#endif
