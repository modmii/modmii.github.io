#ifndef _STRNLEN_H_
#define _STRNLEN_H_

#include "types.h"

size_t strnlen(const char *s, size_t maxlen);

#endif
