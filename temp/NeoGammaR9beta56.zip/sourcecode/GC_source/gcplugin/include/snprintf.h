#ifndef _SNPRINTF_H_
#define _SNPRINTF_H_

#include <stdarg.h>

int vsnprintf(char *b, int len, const char *fmt, va_list pvar) ;

#endif
