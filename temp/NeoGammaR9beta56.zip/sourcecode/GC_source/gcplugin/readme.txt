The code is GPL and is allowed to be linked against Nintendo code.

WiiGator
