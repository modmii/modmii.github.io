#ifndef _SCREEN_H_
#define _SCREEN_H_

void clearScreen(void);

#endif
