#ifndef _CODECMP_H_
#define _CODECMP_H_

#include <stdint.h>
#include <gctypes.h>

int codecmp(void *checkedCode, const u32 *condition, u32 size);

#endif
