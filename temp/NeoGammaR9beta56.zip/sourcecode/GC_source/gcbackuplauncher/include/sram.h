#include <ogcsys.h>
#include <gccore.h>

void setSRAMvideomode(int videomode);
u8 getSRAMlanguage();
u8 getSRAMflags();
void setSRAMflags(u8 flags);