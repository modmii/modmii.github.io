#include <ogcsys.h>

void DrawBackground(GXRModeObj *vmode, u32 xfb);

