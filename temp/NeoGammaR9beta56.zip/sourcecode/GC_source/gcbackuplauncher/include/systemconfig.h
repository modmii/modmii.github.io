#ifndef _SYSTEM_CONFIG_H_

void setup_video(unsigned long mode);
void setup_sys_config();
void setvideomode();
void setup_memory_for_high_plugin();

#endif
