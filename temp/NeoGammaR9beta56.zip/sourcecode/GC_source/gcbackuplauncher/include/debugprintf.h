#ifndef _DEBUG_PRINTF_H_
#define _DEBUG_PRINTF_H_

void debug_printf(const char *fmt, ...);

#endif
