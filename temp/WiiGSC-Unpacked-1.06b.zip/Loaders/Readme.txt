﻿Loaders define in LoaderConfig.xml is stored here. 
If you add a loader you need to define a relevant entry in LoaderConfig.xml too.