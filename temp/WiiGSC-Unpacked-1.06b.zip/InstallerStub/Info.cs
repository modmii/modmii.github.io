using System;
namespace InstallerStub
{
public class Info
{
public static string WadName = "Call of Duty- MW- R  - UJAP - RJAP52.wad";
public static int UncompressedSize = 4782208;
public static int CompressedSize = 1355916;
public static string DefaultIp = "192.168.2.3";
public static int DefaultIos = 249;
}
}
