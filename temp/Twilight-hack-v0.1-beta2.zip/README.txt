============================================================
     Twilight Hack v0.1beta2     2008/11/24      README
     by Team Twiizers (tmbinc, segher, bushing, marcan)
============================================================

=== Introduction ===

This specially crafted savegame for The Legend of Zelda:
Twilight Princess lets you boot homebrew software on your
Wii without any hardware modifications.

Special thanks to drmr for the savegame icons, and to
tmbinc, tehpola, and everyone else who helped during the
"v3.3 bug hunt marathon" after Nintendo released the new
update. Without you, this new version would not be
possible.

Thaks go to Krusty for noticing the strange behavior of
old Twilight Hack saves on 3.4 that ultimately led to this
new bug.

=== Installation ===

You'll need:
- The Legend of Zelda: Twilight Princess (Wii version)
- An SD card, at most 2GB in size.
- An SD card reader
- Some homebrew to load

Copy the 'private' directory from this archive to your SD
card, overwriting any existing Zelda saves or previous
versions of the hack. Find whatever homebrew you wish to
run, copy it to the root of the SD card, and rename it to
boot.dol or boot.elf.

Then, insert the SD card into your Wii, delete the existing
Zelda savefile using the data mangement screen. Switch to
the SD view, locate the right version of the hack for your
region, and copy it over to your Wii. You must have played
Twilight Princess at least once in order for this to work.

If you have the USA version of the game, you must perform
an additional step; please see below. Launch the game.
Select the Twilight Hack savegame, and load it. Once inside
the game, walk backwards. Sit back and enjoy.

Since there are two released versions of Twilight Princess
for the USA region, these users must first check the
version of their game disc. Take your Zelda disc, flip it
over so that the data side is facing you, and look for
a small line of text next to the inner edge of the disc,
between the raised circle of plastic and the data area. If
the text reads "RVL-RZDE-0A-0", you have a v0 game and
you should select the TwilightHack0 savegame. If the text
reads "RVL-RZDE-0A-2", you have a v2 game and you should
select the TwiilghtHack2 savegame. If you do not select
the correct version of the save, the game will freeze and
the hack will not work.

If you are using System Menu 3.4, you can only use the
Twilight Hack the first time right after copying.
Rebooting the Wii or exiting again to the System Menu
will cause the save to be deleted.

=== Uninstallation ===

Just delete the save from the data management screen. If
you're using System Menu 3.4, then it will automatically
delete the Twiilght Hack on every boot.

=== Changelog ===

Changes for this version of the Twilight Hack:

- Workaround for the System Menu 3.4 check. Only works once
  after being copied.

Changes for last version of the Twilight Hack:

- The Twilight Hack is now compatible with version 3.3 of
  the Wii System Menu.

- Improvements in video configuration. The entire console
  should now be visible in all video modes, and scrolling
  has been improved.

- For the USA version, the two variants of the hack have
  been packed into one save file. Just select the save
  slot that corresponds to your version of Twilight
  Princess when you start the game.

- New savegame icons by drmr. The new icons now show which
  region that version of the hack is for.

- This version now tries to load boot.dol, and falls back
  to boot.elf if boot.dol is not found.

- ???????

- Many, many bug fixes.

=== Further Information and Resources ===

http://www.wiibrew.org/wiki/Twilight_Hack
 Up to date info and FAQs

http://www.wiibrew.org/
 General information on Wii homebrew

http://hackmii.com
 Techical blog maintained by Team Twiizers

http://hbc.hackmii.com
 The Homebrew Channel, an installable homebrew launcher
 for your Wii, by Team Twiizers.

============================================================
