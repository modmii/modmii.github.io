ModMii_Syscheck_CSV_Context_Installer_and_Uninstaller READ ME

Save the bat files to ModMii's Support folder, then run the installer bat file to install, and the uninstaller bat file to uninstall.

When installed, a new item will appear in the right-click menu for .csv files called "Analyze Syscheck Log using ModMii".

XFlak